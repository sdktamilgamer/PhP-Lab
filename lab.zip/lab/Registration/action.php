<html>
    <head>

    </head>

    <body>
        <?php
            echo "<h3>This program is Done by me.</h3> <br>"; 
            $name = $_GET['name']; 
            $number = $_GET['number']; 
            $email = $_GET['email']; 
            
            echo "Your Name is $name<br>"; 
            echo "Your Number is $number<br>"; 
            echo "Your Email is $email<br>";
        ?>
    </body>
</html>