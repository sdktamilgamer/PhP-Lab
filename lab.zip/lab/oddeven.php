<html>
    <head>

    </head>

    <body>
        <?php
            $num = 20; 
            echo "<h2>This Program is Done by me.</h2>"; 
            echo "<br />" ;   
            if($num%2 == 0){
                echo "$num is even";  
            }else{
                echo "$num is odd";  
            }
        ?>
    </body>
</html>